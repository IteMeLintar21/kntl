#!/bin/bash

set -e  # Berhenti jika ada perintah yang gagal

fix_apt_lock() {
    echo "Mendeteksi masalah lock pada apt, mencoba memperbaiki..."
    sudo killall apt apt-get 2>/dev/null || true
    sudo rm -f /var/lib/dpkg/lock-frontend /var/lib/dpkg/lock /var/cache/apt/archives/lock
    sudo dpkg --configure -a || true
    sudo apt update -y
}

echo "Melakukan update dan upgrade sistem..."
sudo apt update -y || fix_apt_lock
sudo apt upgrade -y || fix_apt_lock

echo "Menginstall dependencies..."
sudo apt install -y curl python3 python3-pip nodejs || fix_apt_lock

echo "Menginstall package Python tambahan..."
pip3 install --no-cache-dir asyncio aiohttp aiofiles

echo "Menginstall package npm..."
npm_packages=(pm2 socks node-fetch header-generator fake-useragent axios random-useragent user-agents colors hpack http2-wrapper)
sudo npm install -g "${npm_packages[@]}"

echo "Menghentikan proses pm2 proxy jika berjalan..."
pm2 stop PROXY 2>/dev/null || true
pm2 stop proxy 2>/dev/null || true

if ! command -v nvm &> /dev/null; then
    echo "Menginstall nvm..."
    curl -fsSL https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash
    export NVM_DIR="$HOME/.nvm"
    [ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh"
    [ -s "$NVM_DIR/bash_completion" ] && \. "$NVM_DIR/bash_completion"
else
    echo "nvm sudah terinstall."
fi

echo "Menginstall dan mengatur Node.js versi 20..."
nvm install 20
nvm use 20

if ! grep -q "NVM_DIR" ~/.bashrc; then
    echo "Menambahkan konfigurasi nvm ke ~/.bashrc"
    echo 'export NVM_DIR="$HOME/.nvm"' >> ~/.bashrc
    echo '[ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh"' >> ~/.bashrc
    echo '[ -s "$NVM_DIR/bash_completion" ] && \. "$NVM_DIR/bash_completion"' >> ~/.bashrc
fi

echo "Setup selesai!"
